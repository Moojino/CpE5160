/*
 * UART_Functions.c
 *
 * Created: 9/21/2023 8:50:04 PM
 *  Author: Admin
 */ 
#ifndef UART_C_
#define UART_C_

#include "UART.h"

uint8_t UART_Init(volatile uint8_t* UART_addr, uint32_t baud_rate);
uint8_t UART_transmit(volatile uint8_t* UART_addr, uint8_t send_byte);
uint8_t UART_receive(volatile uint8_t* UART_addr);
// Optional, for bonus points
uint8_t UART_Receive_nb(volatile uint8_t* UART_addr);



#endif /* UART_C_ *