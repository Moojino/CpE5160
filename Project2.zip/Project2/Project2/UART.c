/*
 * UART_Functions.c
 *
 * Created: 9/21/2023 8:50:04 PM
 *  Author: Admin
 */ 
#ifndef UART_C_
#define UART_C_

#include "UART.h"

uint8_t UART_Init(volatile uint8_t* UART_addr, uint32_t baud_rate) {
	uint16_t UBRRvalue;
	// Set UBRR based on Baud rate and U2X_bit
	// Rounding formula, (A+B/2)/B
	UBRRvalue = (uint16_t)((((F_CPU/OSC_DIV)+(4UL*(2-U2X_bit)*baud_rate))/(8UL*(2-U2X_bit)*baud_rate))-1);
	UART_addr->UBRRH = UBRRvalue / 256;
	UART_addr->UBRRL = UBRRvalue % 256;
	
	UART_addr->UCSRA = (U2X_bit<<U2X);
	UART_addr->UCSRC = (Async_mode | No_parity | One_stop_bit | eight_bits | 0); // UCPOL = 0
	UART_addr->UCSRB = (TX_EN | RX_EN);
}

uint8_t UART_transmit(volatile uint8_t* UART_addr, uint8_t send_byte);
uint8_t UART_receive(volatile uint8_t* UART_addr);
// Optional, for bonus points
uint8_t UART_Receive_nb(volatile uint8_t* UART_addr);



#endif /* UART_C_ *