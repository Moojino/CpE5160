/*
 * Project2.c
 *
 * Created: 9/21/2023 8:40:05 PM
 * Author : Admin
 */ 

#include <avr/io.h>

int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

