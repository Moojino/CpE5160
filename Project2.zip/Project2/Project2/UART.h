/*
 * UART_Functions.h
 *
 * Created: 9/21/2023 8:49:39 PM
 *  Author: Admin
 */ 
#ifndef UART_H_
#define UART_H_

typedef struct UART {
	volatile uint8_t UCSRA;
	volatile uint8_t UCSRB;
	volatile uint8_t UCSRC;
	volatile uint8_t UCSRD;
	volatile uint8_t UBRRL;
	volatile uint8_t UBRRH;
	volatile uint8_t UDR;
	} UART_t;
	
#define UART0 ((volatile UART_t*)(&UCSR0A))
#define UART1 ((volatile UART_t*)(&UCSR1A))
#define UART2 ((volatile UART_t*)(&UCSR2A))

uint8_t UART_Init(volatile uint8_t* UART_addr, uint32_t baud_rate);

uint8_t UART_transmit(volatile uint8_t* UART_addr, uint8_t send_byte);

uint8_t UART_receive(volatile uint8_t* UART_addr);

// Optional, for bonus points
uint8_t UART_Receive_nb(volatile uint8_t* UART_addr);



#endif /* UART_H_ */