/*
 * UART_Functions.h
 *
 * Created: 9/21/2023 8:49:39 PM
 *  Author: Admin
 */ 
#ifndef UART_H_
#define UART_H_

/* Private constants ====================================*/

#define U2X_bit (0) // Not sure if needs to be 1 or 0
#define RX_EN (1<<4)
#define TX_EN (1<<3)

// UMSEL
#define Async_mode (0<<6)
#define Sync_mode (1<<6)
#define SPI (3<<6)

// UPM
#define No_parity (0<<4)
#define Even_parity (2<<4)
#define Odd_parity (3<<4)

// USBS
#define One_stop_bit (0<<3)
#define Two_stop_bits (1<<3)

// UCSZ, incomplete
#define five_bits (0<<1)
#define six_bits (1<<1)
#define seven_bits (2<<1)
#define eight_bits (3<<1)

/*==================================================*/

typedef struct UART {
	volatile uint8_t UCSRA;
	volatile uint8_t UCSRB;
	volatile uint8_t UCSRC;
	volatile uint8_t UCSRD;
	volatile uint8_t UBRRL;
	volatile uint8_t UBRRH;
	volatile uint8_t UDR;
	} UART_t;
	
#define UART0 ((volatile UART_t*)(&UCSR0A))
#define UART1 ((volatile UART_t*)(&UCSR1A))
#define UART2 ((volatile UART_t*)(&UCSR2A))

uint8_t UART_Init(volatile uint8_t* UART_addr, uint32_t baud_rate);

uint8_t UART_transmit(volatile uint8_t* UART_addr, uint8_t send_byte);

uint8_t UART_receive(volatile uint8_t* UART_addr);

// Optional, for bonus points
uint8_t UART_Receive_nb(volatile uint8_t* UART_addr);



#endif /* UART_H_ */