#ifndef _print_bytes_H
#define _print_bytes_H





// ------ Public function prototypes -------------------------------

void print_memory(uint8_t * array_in, uint16_t number_of_bytes);


#endif