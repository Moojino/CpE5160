/*
 * delay_function.h
 *
 * Created: 8/21/2020 10:11:17 PM
 *  Author: ryoun
 */ 


#ifndef DELAY_FUNCTION_H_
#define DELAY_FUNCTION_H_

void Delay_Loop_ms(unsigned int num_ms);


#endif /* DELAY_FUNCTION_H_ */