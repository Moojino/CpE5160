/*
 * switch_read.h
 *
 * Created: 9/13/2023 7:01:50 PM
 * Author : Ian, Thomas, Dominic
 */ 

 #ifndef _SWITCH_READ_H_
 #define _SWITCH_READ_H_

 #include "GPIO_IO.h"

#define SW0_PORT PC
#define SW0_BIT (6)
#define SW1_PORT PB
#define SW1_BIT (2)
#define SW2_PORT PA
#define SW2_BIT (4)
#define SW3_PORT PA
#define SW3_BIT (5)

void Switch_Init();
uint8_t Read_Switch(uint8_t switch_num);

 #endif /* _SWITCH_READ_H_ */