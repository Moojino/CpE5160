/*
 * GPIO_Outputs.c
 *
 * Created: 9/13/2023 5:22 PM
 *  Author: Ian, Thomas, Dominic
 */ 

#include <avr/io.h>
#include "board.h"
#include "GPIO_IO.h"

void GPIO_Output_Init(volatile GPIO_port_t * port_addr, uint8_t pin_mask)
{
	// Set DDRx bit to make port pin an output
	port_addr -> DDR_REG |=(pin_mask);
}

void GPIO_Output_Control(volatile GPIO_port_t * port_addr, uint8_t pin_mask, uint8_t control)
{
	if(control == 0)
	{
		// Clear PORTx bit to make port pin a �0�
		port_addr-> PORT_REG |= (pin_mask);
	}
	else if (control == 1)
	{
		port_addr-> PORT_REG &= ~(pin_mask);
	}
}

void GPIO_Input_Init(volatile GPIO_port_t * port_addr, uint8_t pin_mask, uint8_t pullup_enable){
		port_addr -> DDR_REG &= ~(pin_mask);
		if (pullup_enable == 0) {
			port_addr -> PORT_REG &= ~(pin_mask);
		}
		else {
			port_addr -> PORT_REG |= (pin_mask);
		}
}

uint8_t GPIO_Input_Read_Pin(volatile GPIO_port_t * port_addr, uint8_t pin_mask){
	return ((port_addr -> PIN_REG) & pin_mask);
}