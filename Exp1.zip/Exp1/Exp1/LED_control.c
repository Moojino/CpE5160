/*
 * LED_control.c
 *
 * Created: 9/13/2023 5:43:10 PM
 *  Author: Ian, Thomas, Dominic
 */ 

#include <avr/io.h>
#include "board.h"
#include "LED_control.h"


void LED_Init(uint8_t LED_num) {
	if (LED_num == 0) {
		GPIO_Output_Init(LED0_PORT, (1<<LED0_BIT));
		GPIO_Output_Control(LED0_PORT, (1<<LED0_BIT), 0);
	}
	else if (LED_num == 1) {
		GPIO_Output_Init(LED1_PORT, (1<<LED1_BIT));
		GPIO_Output_Control(LED1_PORT, (1<<LED1_BIT), 0);
	}
	else if (LED_num == 2) {
		GPIO_Output_Init(LED2_PORT, (1<<LED2_BIT));
		GPIO_Output_Control(LED2_PORT, (1<<LED2_BIT), 0);
	}
	else if (LED_num == 3) {
		GPIO_Output_Init(LED3_PORT, (1<<LED3_BIT));
		GPIO_Output_Control(LED3_PORT, (1<<LED3_BIT), 0);
	}
}

void LED_Control(uint8_t LED_num, uint8_t control){
	if (LED_num == 0) {
		GPIO_Output_Control(LED0_PORT, (1<<LED0_BIT), control);
	}
	else if (LED_num == 1) {
		GPIO_Output_Control(LED1_PORT, (1<<LED1_BIT), control);
	}
	else if (LED_num == 2) {
		GPIO_Output_Control(LED2_PORT, (1<<LED2_BIT), control);
	}
	else if (LED_num == 3) {
		GPIO_Output_Control(LED3_PORT, (1<<LED3_BIT), control);
	}
}
