/*
 * Hello_Embedded_World.c
 *
 * Created: 9/13/2023 5:48:08 PM
 * Author : Ian, Thomas, Dominic
 */ 

#include <avr/io.h>
#include "delay_function.h"
#include "LED_control.h"
#include "switch_read.h"


int main(void)
{
	LED_Init(0);
	LED_Init(1);
	LED_Init(2);
	LED_Init(3);
	Switch_Init();

    while (1) 
    {
	/*	// Turns LEDs on
		LED_Control(0, 1);
		LED_Control(1, 1); 
		LED_Control(2, 1); 
		LED_Control(3, 1); 
		Delay_Loop_ms(1000);
		// Turns LEDs off
		LED_Control(0, 0);
		LED_Control(1, 0); 
		LED_Control(2, 0); 
		LED_Control(3, 0); 
		Delay_Loop_ms(1000); */
		if (Read_Switch(0) == 0) { // Pressed
			Delay_Loop_ms(10); // Debounce handling
			while (Read_Switch(0) == 0); // Wait until unpressed
			LED_Control(0, 1); // Turn on LED0
			while (Read_Switch(0) != 0);
			do {
				LED_Control(0, 1);
				Delay_Loop_ms(100); // On for 0.1s
				LED_Control(0, 0);
				Delay_Loop_ms(400); // Off for 0.4s
			} while (Read_Switch(0) != 0);
		}
		else {
			LED_Control(0, 0);	
		}
		
		if (Read_Switch(1) == 0) { // Pressed
			Delay_Loop_ms(10); // Debounce handling
			while (Read_Switch(1) == 0); // Wait until unpressed
			LED_Control(1, 1); // Turn on LED0
			while (Read_Switch(1) != 0);
			do {
				LED_Control(1, 1);
				Delay_Loop_ms(100); // On for 0.1s
				LED_Control(1, 0);
				Delay_Loop_ms(400); // Off for 0.4s
			} while (Read_Switch(1) != 0);
		}
		else {
			LED_Control(1, 0);
		}
		
		
		if (Read_Switch(2) == 0) { // Pressed
			Delay_Loop_ms(10); // Debounce handling
			while (Read_Switch(2) == 0); // Wait until unpressed
			LED_Control(2, 1); // Turn on LED0
			while (Read_Switch(2) != 0);
			do {
				LED_Control(2, 1);
				Delay_Loop_ms(100); // On for 0.1s
				LED_Control(2, 0);
				Delay_Loop_ms(400); // Off for 0.4s
			} while (Read_Switch(2) != 0);
		}
		else {
			LED_Control(2, 0);
		}
		
		if (Read_Switch(3) == 0) { // Pressed
			Delay_Loop_ms(10); // Debounce handling
			while (Read_Switch(3) == 0); // Wait until unpressed
			LED_Control(3, 1); // Turn on LED0
			while (Read_Switch(3) != 0);
			do {
				LED_Control(3, 1);
				Delay_Loop_ms(100); // On for 0.1s
				LED_Control(3, 0);
				Delay_Loop_ms(400); // Off for 0.4s
			} while (Read_Switch(3) != 0);
		}
		else {
			LED_Control(3, 0);
		}
		Delay_Loop_ms(400);
		
		
    }
	return 0;
}





