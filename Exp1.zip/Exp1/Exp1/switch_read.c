/*
 * switch_read.c
 *
 * Created: 9/13/2023 7:02:04 PM
 *  Author: imtm5c
 */ 

#include "switch_read.h"

// Initializes all the switches with pullup resistors enabled by default
void Switch_Init() {
	GPIO_Input_Init(SW0_PORT, (1<<SW0_BIT), 1);
	GPIO_Input_Init(SW1_PORT, (1<<SW1_BIT), 1);
	GPIO_Input_Init(SW2_PORT, (1<<SW2_BIT), 1);
	GPIO_Input_Init(SW3_PORT, (1<<SW3_BIT), 1);
}

// Accepts input of number of switch being read (Only input 0-3)
uint8_t Read_Switch(uint8_t switch_num) {
	if (switch_num == 0) {
		return GPIO_Input_Read_Pin(SW0_PORT, (1<<SW0_BIT)) & (1 << SW0_BIT); 
	}
	else if (switch_num == 1) {
		return GPIO_Input_Read_Pin(SW1_PORT, (1<<SW1_BIT));
	}
	else if (switch_num == 2) {
		return GPIO_Input_Read_Pin(SW2_PORT, (1<<SW2_BIT));
	}
	else if (switch_num == 3) {
		return GPIO_Input_Read_Pin(SW3_PORT, (1<<SW3_BIT));
	}
	else {
		return 1;
	}
}