/*
 * GPIO_inputs.h
 *
 * Created: 9/13/2023 7:04:05 PM
 *  Author: Ian, Thomas, Dominic
 */


 #ifndef _GPIO_INPUTS_H_
 #define _GPIO_INPUTS_H_
 

 typedef struct port_regs
 {
 volatile uint8_t PIN_REG;
 volatile uint8_t DDR_REG;
 volatile uint8_t PORT_REG;
 } GPIO_port_t;

 #define PA ((volatile GPIO_port_t *) &PINA)
 #define PB ((volatile GPIO_port_t *) &PINB)
 #define PC ((volatile GPIO_port_t *) &PINC)
 #define PE ((volatile GPIO_port_t *) &PINE)

 void GPIO_Output_Init(volatile GPIO_port_t * port_addr, uint8_t pin_mask);
 void GPIO_Output_Control(volatile GPIO_port_t * port_addr, uint8_t pin_mask, uint8_t control);

 #endif /* _GPIO_INPUTS_H_ */