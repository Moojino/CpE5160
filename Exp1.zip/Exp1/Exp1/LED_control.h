/*
 * LED_control.h
 *
 * Created: 9/13/2023 5:43:10 PM
 *  Author: Ian, Thomas, Dominic
 */ 

#ifndef _LED_CONTROL_H_
#define _LED_CONTROL_H_

#include "GPIO_IO.h"

#define LED0_PORT PC
#define LED0_BIT (7)
#define LED1_PORT PB
#define LED1_BIT (3)
#define LED2_PORT PE
#define LED2_BIT (4)
#define LED3_PORT PA
#define LED3_BIT (7)

// Accepts LED number in quesiton as input. Call once for each LED 
void LED_Init(uint8_t LED_num);

// Turns LED on or off. Accepts LED number as input. Control=0 for off, =1 for on
void LED_Control(uint8_t LED_num, uint8_t control);

#endif /* _LED_CONTROL_H_ */