/*
 * GPIO_Outputs.h
 *
 * Created: 9/13/2023 5:22 PM
 *  Author: Ian, Thomas, Dominic
 */ 

#include <avr/io.h>
#include "board.h"


#ifndef _GPIO_IO_H_
#define _GPIO_IO_H_

typedef struct port_regs
{
	volatile uint8_t PIN_REG;
	volatile uint8_t DDR_REG;
	volatile uint8_t PORT_REG;
} GPIO_port_t;

#define PA ((volatile GPIO_port_t *) &PINA)
#define PB ((volatile GPIO_port_t *) &PINB)
#define PC ((volatile GPIO_port_t *) &PINC)
#define PE ((volatile GPIO_port_t *) &PINE)

void GPIO_Output_Init(volatile GPIO_port_t * port_addr, uint8_t pin_mask);
void GPIO_Output_Control(volatile GPIO_port_t * port_addr, uint8_t pin_mask, uint8_t control);

// Pullup_enable = 0 for disable, 1 for enable
void GPIO_Input_Init(volatile GPIO_port_t * port_addr, uint8_t pin_mask, uint8_t pullup_enable);

uint8_t GPIO_Input_Read_Pin(volatile GPIO_port_t * port_addr, uint8_t pin_mask);

#endif /* _GPIO_IO_H_ */