/*
 * SD_card.c
 *
 * Created: 10/14/2023 10:19:02 PM
 *  Author:
 */

#include "board.h"
#include "GPIO_Outputs.h"
#include "SPI.h"
#include "SD_card.h"

uint8_t send_command(uint8_t command, uint32_t argument) {
  uint8_t SPI_error_code;
  if (command > 63) {// Value more than 6 bits
    return SD_illegal_command;
  }
  command |= 0x40; // Append start and transmission bits
  SPI_error_code = SPI_transmit(SD_Card_Port, command);
  if (SPI_error_code != SPI_no_errors) {
    return SD_tx_error;
  }
  SPI_error_code = SPI_transmit(SD_Card_Port, (uint8_t)(argument >> 24));
  SPI_error_code = SPI_transmit(SD_Card_Port, (uint8_t)(argument >> 16));
  SPI_error_code = SPI_transmit(SD_Card_Port, (uint8_t)(argument >> 8));
  SPI_error_code = SPI_transmit(SD_Card_Port, (uint8_t)argument);
  if (SPI_error_code != SPI_no_errors) { // Only cheking once at the end for the sake of speed
    return SD_tx_error;
  }
  // Send CRC, using easy route
  if(command == 0x40) // CMD0
  {
    SPI_error_code = SPI_transmit(SD_Card_Port, 0x95);
  }
  else if(command == 0x48) // CMD8
  {
    SPI_error_code = SPI_transmit(SD_Card_Port, 0x87);
  }
  else
  {
    SPI_error_code = SPI_transmit(SD_Card_Port, 0x01); // end bit only, CRC7=0
  }
  if (SPI_error_code != SPI_no_errors) {
    return SD_tx_error;
  }
  else {
    return SD_no_errors;
  }
}

uint8_t receive_response(uint8_t number_of_bytes, uint8_t * array_name) {
  uint8_t received_byte;
  uint8_t SPI_error_code;
  uint8_t timeout = 0; // Might need to raise this to 16 bit
  do {
    SPI_error_code = SPI_receive(SD_Card_Port, &received_byte);
    timeout++;
  // If MSB is not 0 (response not ready yet) OR lower nibble all 1s (same, but startup error made MSB 0)
  } while (((received_byte == 0xFF) || ((received_byte >> 4) == 0x0F)) && (timeout != 0)); 
  if (timeout == 0) {
	SPI_error_code = SPI_transmit(SD_Card_Port, 0xFF); // Send extra clock signals
    return SD_timeout_error;
  }
  if (received_byte > 0x01) {
    *array_name = received_byte; // Put byte in array to see R1 error
	SPI_error_code = SPI_transmit(SD_Card_Port, 0xFF); // Send extra clock signals
    return SD_R1_error;
  }
  *array_name = received_byte;
  for (uint8_t i = 1; i < number_of_bytes; i++) { // If num bytes = 1, this loop is skipped
    SPI_error_code = SPI_receive(SD_Card_Port, &received_byte);
    *(array_name + i) = received_byte;
  }
  SPI_error_code = SPI_transmit(SD_Card_Port, 0xFF); // Send extra clock signals
  return SD_no_errors;
}

uint8_t sd_card_init(void) {
	uint8_t old_card;
	uint8_t error_code;
	uint8_t response[5];
	SPI_Init(SD_Card_Port, 350000); // Initialize at 350kHz
	GPIO_Output_Init(CS_PORT, CS_PIN);
	
	GPIO_Output_Set(CS_PORT, CS_PIN);
	for (uint8_t i = 0; i < 10; i++) { // 80 clock pulses
		error_code = SPI_transmit(SD_Card_Port, 0xFF);
	}
	
	// Send CMD0
	GPIO_Output_Clear(CS_PORT, CS_PIN);
	error_code = send_command(0x00, 0x00000000); // CMD0
	if (error_code != SD_no_errors) {
		return error_code;
	}
	error_code = receive_response(1, response);
	GPIO_Output_Set(CS_PORT, CS_PIN);
	if (error_code != SD_no_errors) { // If R1 response shows some error, or something else went wrong
		return SD_init_failure;
	}

	
	// Send CMD8
	GPIO_Output_Clear(CS_PORT, CS_PIN);
	error_code = send_command(0x08, 0x000001AA); // CMD8
	if (error_code != SD_no_errors) {
		return error_code;
	}
	error_code = receive_response(5, response);
	GPIO_Output_Set(CS_PORT, CS_PIN);
	if (response[0] == 0x05) { // response is R5
		old_card = 1; // True
	}
	else if (response[0] != 0x01) {
		return SD_R1_error;
	}
	else {
		old_card = 0; // False
		if ((response[3] != 0x01) || (response[4] != 0xAA)) { // If last 2 bytes of response don't match
			return SD_incompatible_voltage;
		}
	}

	
	// CMD58
	GPIO_Output_Clear(CS_PORT, CS_PIN);
	error_code = send_command(0x3A, 0x00000000);
	error_code = receive_response(5, response);
	GPIO_Output_Set(CS_PORT, CS_PIN);
	if (response[0] != 0x01) {				
		return SD_R1_error;
	}
	if (((response[3] & 0b00011110) != 0b00011110)) { // Check OCR bits 19-22 for compatible voltage range
		return SD_incompatible_voltage;
	}
	
}
