/*
 * Project3.c
 *
 * Created: 10/18/2023 2:58:05 PM
 * Author : tahhhy
 */ 

#include <avr/io.h>


int main(void)
{
	sd_card_init();
}

