/*
 * UART_Functions.c
 *
 * Created: 9/21/2023 8:50:04 PM
 *  Author: Admin
 */ 
#ifndef UART_C_
#define UART_C_

#include "board.h"
#include "UART.h"

/* Private constants ====================================*/

#define U2X_bit (0) // Not sure if needs to be 1 or 0
#define RX_EN (1<<4)
#define TX_EN (1<<3)

// UMSEL
#define Async_mode (0<<6)
#define Sync_mode (1<<6)
#define SPI (3<<6)

// UPM
#define No_parity (0<<4)
#define Even_parity (2<<4)
#define Odd_parity (3<<4)

// USBS
#define One_stop_bit (0<<3)
#define Two_stop_bits (1<<3)

// UCSZ, incomplete
#define five_bits (0<<1)
#define six_bits (1<<1)
#define seven_bits (2<<1)
#define eight_bits (3<<1)


uint8_t UART_Init(volatile UART_t* UART_addr, uint32_t baud_rate) { //baudr rate should be 103 when passed in
	uint16_t UBRRvalue;
	// Set UBRR based on Baud rate and U2X_bit
	// Rounding formula, (A+B/2)/B
	UBRRvalue = (uint16_t)((((F_CPU/OSC_DIV)+(4UL*(2-U2X_bit)*baud_rate))/(8UL*(2-U2X_bit)*baud_rate))-1);
	UART_addr->UBBRH = UBRRvalue / 256;
	UART_addr->UBBRL = UBRRvalue % 256;
	
	UART_addr->UCSRA = (U2X_bit<<U2X);
	UART_addr->UCSRC = (Async_mode | No_parity | One_stop_bit | eight_bits | 0); // UCPOL = 0
	UART_addr->UCSRB = (TX_EN | RX_EN);
}

uint8_t UART_transmit(volatile UART_t* UART_addr, uint8_t send_byte){
	uint8_t status;
	do{
		//Read the status bit in UCSRA
		status = UART_addr->UCSRA; //it may need to bed UART_UCSRA?
		//AND to isolate only UDRE, repeat while UDRE==0
		//UDRE is a bit value defined in <avr/io.h>
	} while ((status & (1 << UDRE)) != (1 << UDRE));

	//place the send_value into the USART data register
	UART_addr->UDR = send_byte;

	return 0;
}

uint8_t UART_receive(volatile UART_t* UART_addr){
	while(((UART_addr->UCSRA) & (1 << RXC)) == 0);//Wait Until data is received
	return UART_addr->UDR;//Returns received value
}


// Optional, for bonus points
uint8_t UART_Receive_nb(volatile UART_t* UART_addr, uint8_t *rcvd_value){
	if((UART_addr->UCSRA) & (1 << RXC) == 1){	
		*rcvd_value = UART_addr -> UDR;
		return 1;
	}
	return 0;
}



#endif /* UART_C_ */