/*
 * UART_Functions.h
 *
 * Created: 9/21/2023 8:49:39 PM
 *  Author: Admin
 */ 
#ifndef UART_H_
#define UART_H_


uint8_t UART_Init(volatile UART_t* UART_addr, uint32_t baud_rate);

uint8_t UART_transmit(volatile UART_t* UART_addr, uint8_t send_byte);

uint8_t UART_receive(volatile UART_t* UART_addr);

// Optional, for bonus points
uint8_t UART_Receive_nb(volatile UART_t* UART_addr, uint8_t *rcvd_value);



#endif /* UART_H_ */