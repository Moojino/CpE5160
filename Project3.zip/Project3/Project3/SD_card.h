/*
 * SD_card.h
 *
 * Created: 10/14/2023 10:18:38 PM
 *  Author: 
 */ 

#ifndef _SD_CARD_H_
#define _SD_CARD_H_

#define SD_Card_Port SPI0

// Error codes
#define SD_no_errors (0)
#define SD_illegal_command (1)
#define SD_tx_error (2)
#define SD_timeout_error (3)
#define SD_R1_error (4)
#define SD_init_failure (5)
#define SD_incompatible_voltage (6)

uint8_t send_command(uint8_t command, uint32_t argument);
uint8_t receive_response(uint8_t number_of_bytes, uint8_t * array_name);
uint8_t sd_card_init(void);

#endif /* _SD_CARD_H_ */

