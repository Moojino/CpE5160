/*
 * SPI.c
 *
 * Created: 10/9/2023
 *  Author: 
 */ 

// Private constants =======================================
#define CPOL_bit (0) // Transmitter's idle state
#define CPHA_bit (0) // Determines the sampler's timing (0=1st clock edge, 1=2nd clock edge)
//==========================================================

#include "SPI.h"
#include "GPIO_Outputs.h"
#include "board.h"

uint8_t SPI_Init(volatile SPI_t *SPI_addr, uint32_t clock_rate) {
	uint8_t divider = (uint8_t)((F_CPU / OSC_DIV) / clock_rate);
	if (divider < 2) {
		SPI_addr->SPSR = (1 << SPI2X);
		SPI_addr->SPCR = ((1 << SPE) | (1 << MSTR) | (CPOL_bit << CPOL) |
		(CPHA_bit << CPHA) | 0); // SPR = 00
		} else if (divider < 4) {
		SPI_addr->SPSR = 0;
		SPI_addr->SPCR = ((1 << SPE) | (1 << MSTR) | (CPOL_bit << CPOL) |
		(CPHA_bit << CPHA) | 0); // SPR = 00
		} else if (divider < 8) {
		SPI_addr->SPSR = (1 << SPI2X);
		SPI_addr->SPCR = ((1 << SPE) | (1 << MSTR) | (CPOL_bit << CPOL) |
		(CPHA_bit << CPHA) | 0x01); // SPR = 01
		} else if (divider < 16) {
		SPI_addr->SPSR = 0;
		SPI_addr->SPCR = ((1 << SPE) | (1 << MSTR) | (CPOL_bit << CPOL) |
		(CPHA_bit << CPHA) | 0x01); // SPR = 01
		} else if (divider < 32) {
		SPI_addr->SPSR = (1 << SPI2X);
		SPI_addr->SPCR = ((1 << SPE) | (1 << MSTR) | (CPOL_bit << CPOL) |
		(CPHA_bit << CPHA) | 0x02); // SPR = 10
		} else if (divider < 64) {
		SPI_addr->SPSR = (1 << SPI2X);
		SPI_addr->SPCR = ((1 << SPE) | (1 << MSTR) | (CPOL_bit << CPOL) |
		(CPHA_bit << CPHA) | 0x03); // SPR = 11
		} else if (divider < 128) {
		SPI_addr->SPSR = 0;
		SPI_addr->SPCR = ((1 << SPE) | (1 << MSTR) | (CPOL_bit << CPOL) |
		(CPHA_bit << CPHA) | 0x03); // SPR = 11
		} else {
		return SPI_divider_too_high;
	}
	// Set MOSI, SCK pins as output, initial values = 1, CPOL, respectively
	if (SPI_addr == SPI0) {
		// MOSI pin
		GPIO_Output_Init(PB, (1 << 5));
		GPIO_Output_Set(PB, (1 << 5));
		// SCK pin
		GPIO_Output_Init(PB, (1 << 7));
		if (CPOL_bit == 0) {
			GPIO_Output_Clear(PB, (1 << 7));
			} else { // CPOL = 1
			GPIO_Output_Set(PB, (1 << 7));
		}
		} else if (SPI_addr == SPI1) {
		// MOSI pin
		GPIO_Output_Init(PE, (1 << 3));
		GPIO_Output_Set(PE, (1 << 3));
		// SCK pin
		GPIO_Output_Init(PD, (1 << 7));
		if (CPOL_bit == 0) {
			GPIO_Output_Clear(PD, (1 << 7));
			} else { // CPOL = 1
			GPIO_Output_Set(PD, (1 << 7));
		}
	}
	return SPI_no_errors;
}

uint8_t SPI_transmit(volatile SPI_t *SPI_addr, uint8_t send_value) {
	uint8_t status;
	uint8_t return_value;
	(SPI_addr->SPDR) = send_value;
	uint16_t timeout = 0;

	do {
		status = (SPI_addr->SPSR);
		timeout++;
	} while (((status & 0xC0) == 0) && (timeout != 0));

	if (timeout == 0) { // timeout error
		return_value = SPI_timeout_error;
		} else if ((status & 0x40) != 0) {
		return_value = SPI_tx_error;
		} else {
		return_value = SPI_no_errors;
	}

	return return_value;
}

uint8_t SPI_receive(volatile SPI_t *SPI_addr, uint8_t *rec_value) {
	uint8_t status;
	uint8_t return_value;
	SPI_addr->SPDR = 0xFF;
	uint16_t timeout = 0;

	do {
		status = (SPI_addr->SPSR);
		timeout++;
	} while (((status & 0xC0) == 0) && (timeout != 0));

	if (timeout == 0) { // timeout error
		return_value = SPI_timeout_error;
		} else if ((status & 0x40) != 0) {
		return_value = SPI_tx_error;
		*rec_value = (SPI_addr->SPDR); // Clears the WCOL flag
		} else {
		return_value = SPI_no_errors;
		*rec_value = (SPI_addr->SPDR);
	}

	return return_value;
}

uint8_t SPI_transfer(volatile SPI_t *SPI_addr, uint8_t send_value,
uint8_t *rec_value) {
	uint8_t status;
	uint8_t return_value;
	(SPI_addr->SPDR) = send_value;
	uint16_t timeout = 0;

	do {
		status = (SPI_addr->SPSR);
		timeout++;
	} while (((status & 0xC0) == 0) && (timeout != 0));

	if (timeout == 0) { // timeout error
		return_value = SPI_timeout_error;
		} else if ((status & 0x40) != 0) {
		return_value = SPI_tx_error;
		*rec_value = (SPI_addr->SPDR); // Clears the WCOL flag
		} else {
		return_value = SPI_no_errors;
		*rec_value = (SPI_addr->SPDR);
	}

	return return_value;
}