#ifndef _SPI_H
#define _SPI_H

#include "board.h"

// Public Constants===========================================
// Error codes
#define SPI_no_errors (0)
#define SPI_divider_too_high (1)
#define SPI_timeout_error (2)
#define SPI_tx_error (3)
//==============================================================

uint8_t SPI_Init(volatile SPI_t* SPI_addr, uint32_t clock_rate);
uint8_t SPI_transmit(volatile SPI_t *SPI_addr, uint8_t send_value);
uint8_t SPI_receive(volatile SPI_t *SPI_addr, uint8_t *rec_value);
uint8_t SPI_transfer(volatile SPI_t *SPI_addr, uint8_t send_value, uint8_t *rec_value);

#endif /* _SPI_H_ */

